from typing import Callable

from langgraph.graph.state import CompiledStateGraph

from og_agents.config import AppConfig
from og_agents.state import GenerationState
from og_agents.workflows.nodes import (
    BaseNode,
    CodingAgentNoCoreNode,
    CodingAgentNode,
    DocumentsLoadingNode,
    GenerateCompetencyQuestionsNode,
    GenerateOntologyNode,
    OOPSOntologyValidationNode,
    OntologyConsistencyValidationNode,
    OntologyRDFSyntaxValidationNode,
    SaveOntologyNode,
)
from og_agents.workflows.ontology_generation_workflow_builder import (
    OntologyGenerationWorkflowBuilder,
)
from og_agents.workflows.requests import GenerateOntologyRequest
from og_agents.workflows.workflow_context import WorkflowContext

CompiledOntologyWorkflow = CompiledStateGraph[
    GenerationState, WorkflowContext, GenerateOntologyRequest
]

PipelineFactory = Callable[..., CompiledOntologyWorkflow]


def _maybe_cq(use_cq: bool) -> list[BaseNode]:
    return [GenerateCompetencyQuestionsNode()] if use_cq else []


def legacy_llm_pipeline(
    config: AppConfig, *, use_cq: bool = True
) -> CompiledOntologyWorkflow:
    """LLM directly emits Turtle from CQ + source text. No coding agent.

    The validation node guards against malformed Turtle that the LLM
    occasionally emits (stray prose, missing prefix, etc.) by asking the
    model to repair it.
    """
    nodes: list[BaseNode] = _maybe_cq(use_cq) + [
        GenerateOntologyNode(),
        OntologyRDFSyntaxValidationNode(),
    ]
    return OntologyGenerationWorkflowBuilder.of(nodes).build()


def coding_no_core_pipeline(
    config: AppConfig, *, use_cq: bool = True
) -> CompiledOntologyWorkflow:
    """Coding agent without access to the foundational `core` layer."""
    nodes: list[BaseNode] = _maybe_cq(use_cq) + [CodingAgentNoCoreNode(config)]
    return OntologyGenerationWorkflowBuilder.of(nodes).build()


def coding_with_core_pipeline(
    config: AppConfig, *, use_cq: bool = True
) -> CompiledOntologyWorkflow:
    """Coding agent rooted in the foundational `core` layer."""
    nodes: list[BaseNode] = _maybe_cq(use_cq) + [CodingAgentNode(config)]
    return OntologyGenerationWorkflowBuilder.of(nodes).build()


def full_ui_pipeline(config: AppConfig) -> CompiledOntologyWorkflow:
    """Full pipeline used by the Streamlit UI"""
    return OntologyGenerationWorkflowBuilder.of(
        [
            DocumentsLoadingNode(),
            GenerateCompetencyQuestionsNode(),
            CodingAgentNode(config),
            OntologyRDFSyntaxValidationNode(),
            OOPSOntologyValidationNode(),
            OntologyConsistencyValidationNode(),
            SaveOntologyNode(),
        ]
    ).build()


PIPELINE_REGISTRY: dict[str, PipelineFactory] = {
    "legacy_llm": legacy_llm_pipeline,
    "coding_no_core": coding_no_core_pipeline,
    "coding_with_core": coding_with_core_pipeline,
}


__all__ = [
    "PipelineFactory",
    "CompiledOntologyWorkflow",
    "legacy_llm_pipeline",
    "coding_no_core_pipeline",
    "coding_with_core_pipeline",
    "full_ui_pipeline",
    "PIPELINE_REGISTRY",
]
